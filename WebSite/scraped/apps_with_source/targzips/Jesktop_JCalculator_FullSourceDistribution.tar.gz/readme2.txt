      Date: 
	   Fri, 1 Dec 2000 21:02:45 -0800 (PST)
     From: 
	   nyn rkr <nyn@jalwa.com>
       To: 
	   Paul Hammant <Paul.Hammant@bigfoot.com>
    Subject: 
	   Re: JCalculator
  Reply-To: 
	   nyn@jalwa.com
X-Originating-Ip: 
	   [61.11.23.152]
Message-ID: 
	   <20001202050245.DC78B3ECC@sitemail.everyone.net>
X-Mozilla-Status: 
	   8011
X-Mozilla-Status2: 
	   00000000
   X-UIDL: 
	   975733369.45132.radillon.mail.be.easynet.net,S=1866


Please feel free to use my source code.Its FREE!

By the way, where are you from?

All the best for your project.

Regards,

nyn