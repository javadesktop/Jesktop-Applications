This application needs Apache's Ant to compile correctly.

It is available as tools.zip or tools.tar.gz from http://www.jesktop.org/tools.html.

It needs to be unzipped as tools/ within this diretcory or the parent directory 
(for shared tools).  Note that does not mean a direocry like tools/tools/lib it
means tools/bin (etc).