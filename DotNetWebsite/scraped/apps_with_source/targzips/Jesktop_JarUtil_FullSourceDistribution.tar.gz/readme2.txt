Written by Rana Bhattacharyya <rana_b@yahoo.com>

** To run the the app in standalone mode, you need to copy jesktop_frimble.jar to this directory. **

The Author has redesignated this software under APL.

-PH
