import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import com.l2fprod.gui.*;
import com.l2fprod.gui.event.*;
import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.gui.plaf.skin.impl.gtk.*;
import com.l2fprod.gui.plaf.skin.impl.kde.*;
import com.l2fprod.util.WindowUtils;

/**
 * Snapping Demo
 * <br>
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.1.1.1 $, $Date: 2000/07/26 19:32:11 $
 */
public class snap {

    public static void main(String[] args) throws Exception {

	int[] positions = {
	    SwingConstants.NORTH_WEST,
	    SwingConstants.NORTH_EAST,
	    SwingConstants.SOUTH_WEST,
	    SwingConstants.SOUTH_EAST,
	    SwingConstants.WEST,
	    SwingConstants.EAST,
	};

	Frame fw = new Frame();
	for (int i = 0; i < positions.length; i++) {
	    java.awt.Window snap = new ClockSnap(fw);
	    snap.show();
	    WindowSnapping.snap(snap, positions[i]);
	}

	// the snap windows created above will follow any registered window
	Frame f = new Frame("Hello!");
	f.setSize(200, 300);
	// register this window
	WindowSnapping.registerSnapping(f);
	f.show();
	f.setLocation(100, 100);
	
	f = new Frame("Hello!");
	f.setSize(200, 300);
	f.show();
	f.setLocation(300, 150);

	// this window will follow the previous frame
	java.awt.Window snap = new ClockSnap(f);
	snap.show();
	// register the snap window with the previously defined frame
	// the snap window will follow only this frame
	WindowSnapping.snap(snap, SwingConstants.NORTH_WEST, f);
    }

    public static class ClockSnap extends java.awt.Window {
	public ClockSnap(Frame parent) {
	    super(parent);
	    setLayout(new BorderLayout());
	    final Label timeLabel;
	    add("Center",  timeLabel = new Label("00:00:00"));
	    pack();

	    Thread clock = new Thread() {
		    public void run() {
			while (true) {
			    timeLabel.setText(java.text.DateFormat.getTimeInstance().format(new java.util.Date()));
			    try {
				Thread.sleep(500);
			    } catch (Exception e) {}
			}
		    }
		};
	    clock.start();
	}
    }

}
