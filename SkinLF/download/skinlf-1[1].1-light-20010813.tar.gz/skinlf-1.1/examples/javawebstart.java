import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.*;
import javax.swing.*;
import com.l2fprod.gui.*;
import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.util.*;

/**
 * JavaWebStart Test powered by SkinLF and Rachel
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.1 $, $Date: 2001/07/29 20:29:29 $
 */
public class javawebstart {

    /**
     * The main method is called by the java command line and may also be used by Java Web Start
     */
    public static void main(String[] args) throws Exception {
	
	URL themePack = javawebstart.class.getResource("whistlerthemepack/skinlf-themepack.xml");
	
 	SkinLookAndFeel.setSkin(SkinLookAndFeel.loadThemePackDefinition(themePack));
	
	/**
	 * Using custom look and feel with Swing is currently buggy
	 * because Swing is (most of the time) loaded from the system classpath
	 * and call to Class.forName use the system class loader
	 * see http://developer.java.sun.com/developer/bugParade/bugs/4155617.html
	 * for more information on this bug and workaround
	 */
	
	/**
	 * First don't use setLookAndFeel(String) but setLookAndFeel(LookAndFeel)
	 */
	SkinLookAndFeel lnf = new SkinLookAndFeel();
	UIManager.setLookAndFeel(lnf);
	
	/**
	 * Then, specify your own ClassLoader to work around these bugs
	 * Calls to UIManager.getUI() will use the lnf classloader
	 * see javax.swing.UIDefaults#getUI method to understand how this works.
	 */
	UIManager.getLookAndFeelDefaults().put("ClassLoader", lnf.getClass().getClassLoader());

	JFrame f = new JFrame("Skin Test");
	f.getContentPane().setLayout(new BorderLayout());
	f.getContentPane().add("Center", new LnFTestPanel());

	WindowUtils.sizeTo(f, 0.5d, 0.5d);
	WindowUtils.centerOnScreen(f);
	
	f.setVisible(true);
	
	f.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent event) {
		    System.exit(0);
		}
	    });
    }
    
}
