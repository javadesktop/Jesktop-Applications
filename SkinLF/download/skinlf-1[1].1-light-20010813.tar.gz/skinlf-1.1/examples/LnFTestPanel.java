import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.URL;
import javax.swing.*;
import javax.swing.text.*;
import com.l2fprod.gui.*;
import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.util.*;

/**
 * Simple Test Panel for a Look And Feel
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.3 $, $Date: 2001/08/13 20:40:19 $
 */
public class LnFTestPanel extends JPanel {

    public LnFTestPanel() {
	setLayout(new BorderLayout(3, 3));

	// Create the menu bar	
	JMenuBar menubar = new JMenuBar();
	JMenu menu = new JMenu("File");
	menu.add(new JMenuItem("Save"));
	menu.add(new JMenuItem("Open"));
	menu.addSeparator();
	JMenuItem item = new JMenuItem("Exit");
	item.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent event) {
		    exit();
		}
	    });
	menu.add(item);
	menubar.add(menu);

	menu = new JMenu("Edit");
	menu.add(new JCheckBoxMenuItem("CheckBoxMenu Item (selected)", true));
	menu.add(new JCheckBoxMenuItem("CheckBoxMenu Item (unselected)"));
	menu.addSeparator();
	menu.add(new JCheckBoxMenuItem("CheckBoxMenu Item (disabled/selected)", true)).setEnabled(false);
	menu.add(new JCheckBoxMenuItem("CheckBoxMenu Item (disabled/unselected)")).setEnabled(false);
	menu.addSeparator();
	menu.add(new JRadioButtonMenuItem("RadioButtonMenu Item (selected)", true));
	menu.add(new JRadioButtonMenuItem("RadioButtonMenu Item (unselected)"));
	menu.addSeparator();
	menu.add(new JRadioButtonMenuItem("RadioButtonMenu Item (disabled/selected)", true)).setEnabled(false);
	menu.add(new JRadioButtonMenuItem("RadioButtonMenu Item (disabled/unselected)")).setEnabled(false);
	menubar.add(menu);

	menu = new JMenu("Help");
	menu.add(new AbstractAction("About " + SkinLookAndFeel.VERSION) {
		public void actionPerformed(ActionEvent event) {
		    JOptionPane.showMessageDialog(null,
						  "SkinLookAndFeel " + SkinLookAndFeel.VERSION + "\n" +
						  "(c) 2000-2001 L2FProd.com");
		}
	    });
	menubar.add(menu);
	
	add("North", menubar);

	JPanel buttonPane = new JPanel(new VerticalLayout(3));
	JButton button = new JButton("Rollover");
	ButtonModel model = new DefaultButtonModel() {
		public boolean isSelected() {
		    return true;
		}
		public boolean isRollover() {
		    return true;
		}
	    };
	button.setModel(model);
	buttonPane.add(button);
	buttonPane.add(new JButton("Normal"));
	button = new JButton("Pressed");
	model = new DefaultButtonModel() {
		public boolean isPressed() {
		    return true;
		}
		public boolean isArmed() {
		    return true;
		}
		public boolean isSelected() {
		    return true;
		}
	    };
	button.setModel(model);
	buttonPane.add(button);
	button = new JButton("Disabled");
	button.setEnabled(false);
	buttonPane.add(button);

	JPanel common = new JPanel(new GridLayout(4, 2));
	JCheckBox check = new JCheckBox("Check", true);
	common.add(check);
	
	JRadioButton select = new JRadioButton("Select", true);
	common.add(select);

	check = new JCheckBox("Check", false);
	common.add(check);

	select = new JRadioButton("Select", false);
	common.add(select);

	check = new JCheckBox("Check", true);
	check.setEnabled(false);
	common.add(check);

	select = new JRadioButton("Select", true);
	select.setEnabled(false);
	common.add(select);

	check = new JCheckBox("Check", false);
	check.setEnabled(false);
	common.add(check);

	select = new JRadioButton("Select", false);
	select.setEnabled(false);
	common.add(select);

	JProgressBar progress = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
	progress.setValue(75);

	JPanel mainPane = new JPanel(new BorderLayout(3, 3));
	mainPane.add("Center", common);
	mainPane.add("South", progress);
	mainPane.add("East", buttonPane);

	JTabbedPane tabs = new JTabbedPane();
	tabs.addTab("Common", mainPane);
	tabs.addTab("Unselected", new JScrollPane(new JTree()));
	tabs.addTab("Disabled", new JPanel());
	tabs.addTab("InternalFrame", new InternalTest());
	tabs.addTab("TextComponent", new TextTest());
	tabs.addTab("Combo and List", new ComboList());
	tabs.setEnabledAt(2, false);

	add("Center", tabs);

	JScrollBar hsb = new JScrollBar(JScrollBar.HORIZONTAL, 50, 20, 0, 100);
	add("South", hsb);

	JScrollBar vsb = new JScrollBar(JScrollBar.VERTICAL, 50, 20, 0, 100);
	add("East", vsb);
    }

    static class InternalTest extends JPanel {
	InternalTest() {
	    setLayout(new BorderLayout());
	    JDesktopPane desk = new JDesktopPane();
	    add("Center", new JScrollPane(desk));
	    desk.putClientProperty("JDesktopPane.backgroundEnabled", Boolean.TRUE);
	    desk.putClientProperty("JDesktopPane.dragMode", "faster");

	    JInternalFrame frame = new JInternalFrame("A Frame", true, true, true, true);
	    frame.getContentPane().add(new JScrollPane(new JTree()));
	    frame.setVisible(true);
	    frame.setSize(200,100);
	    desk.add(frame);

	    frame = new JInternalFrame("An other Frame", true, true, true, true);
	    frame.getContentPane().add(new JButton("Hello"));
	    frame.setMaximizable(false);
	    frame.setVisible(true);
	    frame.setSize(200,200);
	    frame.setLocation(50,50);
	    desk.add(frame);
	}
    }

    static class TextTest extends JPanel {
	TextTest() {
	    setLayout(new VerticalLayout());
	    add(new JLabel("This is a testbed for the key bindinds"));
	    add(new JLabel("JTextField:"));
	    add(new JTextField("please try the key bindings"));

	    add(new JLabel("JPasswordField:"));
	    add(new JPasswordField());

	    JScrollPane scroll;
	    add(new JLabel("JTextArea:"));
	    add(scroll = new JScrollPane(new JTextArea("please try the key bindings\nthis is skin look and feel",4, 50)));
	    scroll.setPreferredSize(new Dimension(100, 60));

	    add(new JLabel("JTextPane:"));
	    add(scroll = new JScrollPane(new JTextPane()));
	    scroll.setPreferredSize(new Dimension(100, 60));
	    
	    add(new JLabel("JEditorPane:"));
	    add(scroll = new JScrollPane(new JEditorPane()));
	    scroll.setPreferredSize(new Dimension(100, 60));
	}
    }

    static class ComboList extends JPanel {
	ComboList() {
	    setLayout(new VerticalLayout());
	    add(new JLabel("Normal ComboBox:"));
	    add(new JComboBox(new String[]{"1", "2", "4","8"}));
	    add(new JLabel("Editable ComboBox"));
	    JComboBox editable = new JComboBox(new String[]{"1", "2", "4","8"});
	    editable.setEditable(true);
	    add(editable);
	}
    }

    void exit() {
	System.exit(0);
    }

    static public class VerticalLayout implements LayoutManager {
	
	int gap = 0;
	
	public VerticalLayout() {
	}
	
	public VerticalLayout(int gap) {
	    this.gap = gap;
	}
	
	public void addLayoutComponent(String name, Component c) {
	}
	
	public void layoutContainer(Container parent) {
	    Insets insets = parent.getInsets();
	    Dimension size = parent.getSize();
	    int width = size.width - insets.left - insets.right;
	    int height = insets.top;
	    
	    for (int i = 0, c = parent.getComponentCount(); i < c; i++) {
		Component m = parent.getComponent(i);
		if (m.isVisible()) {
		    m.setBounds(insets.left, height, width, m.getPreferredSize().height);
		    height += m.getSize().height + gap;
		}
	    }
	}
	
	public Dimension minimumLayoutSize(Container parent) {
	    return preferredLayoutSize(parent);
	}
	
	public Dimension preferredLayoutSize(Container parent) {
	    Insets insets = parent.getInsets();
	    Dimension pref = new Dimension(0, 0);
	    
	    for (int i = 0, c = parent.getComponentCount(); i < c; i++) {
		Component m = parent.getComponent(i);
		if (m.isVisible()) {
		    pref.height += parent.getComponent(i).getPreferredSize().height + gap;
		    // ADDED
		    pref.width = Math.max(pref.width, parent.getComponent(i).getPreferredSize().width);
		    // END ADDED
		}
	    }
	    
	    pref.height += insets.top + insets.bottom;
	    
	    return pref;
	}
	
	public void removeLayoutComponent(Component c) {
	}
	
    }
}
