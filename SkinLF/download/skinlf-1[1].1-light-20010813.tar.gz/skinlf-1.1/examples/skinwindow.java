/* ====================================================================
 * 
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:  
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.FULLNAME@"
 *    nor may "@PROJECT.FULLNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

/**
 * 
 * Created on 26/05/2001 by Frederic Lavigne, fred@L2FProd.com
 *
 * @author $Author: $
 * @version $Revision: $, $Date: $
 */
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import com.l2fprod.gui.*;
import com.l2fprod.gui.event.*;
import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.gui.plaf.skin.impl.gtk.*;
import com.l2fprod.gui.plaf.skin.impl.kde.*;
import com.l2fprod.util.WindowUtils;

/**
 * Skin Window Demo
 * <br>
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.2 $, $Date: 2000/11/25 20:48:46 $
 */
public class skinwindow {

    public static void main(String[] args) throws Exception {
	
 	SkinLookAndFeel.setSkin(SkinLookAndFeel.loadThemePack(args[0]));

	UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");

	SkinWindow f = new SkinWindow("My First Window"); //"SkinTest - " + args[0]);
	f.getContentPane().add("North", new JButton("Hello"));

	JMenuBar menubar = new JMenuBar();
	menubar.add(new JMenu("File"));
	f.setJMenuBar(menubar);

	WindowUtils.sizeTo(f, 0.5d, 0.5d);
	WindowUtils.centerOnScreen(f);

	f.setVisible(true);

	SkinWindow f2 = new SkinWindow("My Second Window");
	f2.addWindowListener(new SkinWindowAdapter() {
		public void windowShaded(SkinWindowEvent event) {
		    System.out.println("windowShaded");
		}
		public void windowUnshaded(SkinWindowEvent event) {
		    System.out.println("windowUnshaded");
		}
		public void windowIconified(WindowEvent event) {
		    System.out.println("iconified!");
		}
	    });
	f2.getContentPane().add("North", new JButton("Bye"));
	f2.getContentPane().add("Center", new JScrollPane(new JTextArea()));
       
	WindowUtils.sizeTo(f2, 0.2d, 0.2d);

	f2.setVisible(true);

    }

}
