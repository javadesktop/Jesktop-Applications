import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import com.l2fprod.gui.*;
import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.gui.plaf.skin.impl.gtk.*;
import com.l2fprod.gui.plaf.skin.impl.kde.*;
import com.l2fprod.util.WindowUtils;

/**
 * Skin Chooser Demo
 * <br>
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.1.1.1 $, $Date: 2000/07/26 19:32:11 $
 */
public class chooser {

    public static void main(String[] args) throws Exception {

	final SkinChooser skinchooser = new SkinChooser();
	skinchooser.setSkinLocations(args);

	final JFrame frame = new JFrame();
	frame.getContentPane().setLayout(new BorderLayout());
	frame.getContentPane().add("Center", skinchooser);

	((JButton)frame.getContentPane().add("South", new JButton("Update L&F"))).addActionListener(new ActionListener() {public void actionPerformed(ActionEvent event) {
	    try { 
		skinchooser.apply();
		SwingUtilities.updateComponentTreeUI(frame);
	    } catch (Exception e) { e.printStackTrace(); }
	}
	    });
	WindowUtils.sizeTo(frame, 0.5d, 0.5d);
	WindowUtils.centerOnScreen(frame);

	frame.setVisible(true);
    }

}

