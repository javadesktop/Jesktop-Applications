import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

import com.l2fprod.gui.region.*;

/**
 * Simple example for using the Region API.
 * <br>
 * This example creates a region object from the picture using the transparent mask.
 *
 * Created on 02/12/2000 by Frederic Lavigne, fred@L2FProd.com
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.1 $, $Date: 2000/12/22 13:25:24 $
 */
public class imageregion {

    public static void main(String[] args) {
	
        final Image image = Toolkit.getDefaultToolkit().getImage(args[0]);
    
        MediaTracker tracker = new MediaTracker(new Panel());
        tracker.addImage(image, 0);
        try {
            tracker.waitForID(0);
        } catch (Exception ee) {
            System.err.println("interrupted waiting for image!");
        }	

	final JWindow w = new JWindow();
        w.setSize(image.getWidth(null), image.getHeight(null));
	w.setLocation(100, 100);
            
	MouseInputAdapter adapter = new MouseInputAdapter() {
		int pressedX;
		int pressedY;
		public void mousePressed(MouseEvent event) {
		    pressedX = event.getX();
		    pressedY = event.getY();
		}
		public void mouseDragged(MouseEvent event) {
		    Point p = w.getLocation();
		    w.setLocation(p.x + (event.getX() - pressedX),
				  p.y + (event.getY() - pressedY));
		}
	    };

	w.addMouseListener(adapter);
	w.addMouseMotionListener(adapter);

	RegionBuilder.getInstance().setWindowRegion(w, new ImageRegion(image), false);
      
	w.getContentPane().setLayout(new BorderLayout());
	w.getContentPane().add("Center", new JLabel(new ImageIcon(args[0])));

	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	Dimension size = w.getSize();
	w.setLocation((screenSize.width - size.width) / 2,
		      (screenSize.height - size.height) / 2);

	w.show();
    }

}
