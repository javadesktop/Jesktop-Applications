import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

import com.l2fprod.gui.region.*;

/**
 * Simple example for using the Region API.
 * <br>
 * This example creates a region object using the rectangle, polygon primitives
 *
 * Created on 02/12/2000 by Frederic Lavigne, fred@L2FProd.com
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.2 $, $Date: 2000/12/22 13:25:24 $
 */
public class region {

    public static void main(String[] args) {
	
	final JWindow w = new JWindow();
	w.setSize(373,238);
	w.setLocation(100, 100);
            
	MouseInputAdapter adapter = new MouseInputAdapter() {
		int pressedX;
		int pressedY;
		public void mousePressed(MouseEvent event) {
		    pressedX = event.getX();
		    pressedY = event.getY();
		}
		public void mouseDragged(MouseEvent event) {
		    Point p = w.getLocation();
		    w.setLocation(p.x + (event.getX() - pressedX),
				  p.y + (event.getY() - pressedY));
		}
	    };

	w.addMouseListener(adapter);
	w.addMouseMotionListener(adapter);

	// create a rectangle
	Region r1 = RegionBuilder.getInstance().createRoundRectangleRegion(0, 60, 310, 240, 40, 40);
	// create a star
	Region r2 = RegionBuilder.getInstance().createPolygonRegion(new int[]{180,248,275,302,370,332,370,302,218},
					new int[]{45,50,0,50,45,90,136,132,90}, RegionBuilder.FILL_ALTERNATE);
	// merge the two regions
	r1 = RegionBuilder.getInstance().combineRegions(r1, r2, RegionBuilder.REGION_OR);
      
	// set the window region
	RegionBuilder.getInstance().setWindowRegion(w, r1, false);
      
	w.getContentPane().setLayout(new BorderLayout());
	w.getContentPane().add("Center", new JLabel(new ImageIcon("native_splashscreen.gif")));

	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	Dimension size = w.getSize();
	w.setLocation((screenSize.width - size.width) / 2,
		      (screenSize.height - size.height) / 2);

	w.show();
    }

}
