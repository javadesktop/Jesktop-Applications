import javax.swing.*;
import javax.jnlp.*;
import java.net.URL;
import java.io.*;

import com.l2fprod.gui.plaf.skin.*;

/**
 * 
 * Created on 12/04/2001 by Frederic Lavigne, fred@L2FProd.com
 *
 * @author $Author: l2fprod $
 * @version $Revision: 1.2 $, $Date: 2001/06/10 18:18:45 $
 */
public class jnlptest {

    public static void main(String[] args) throws Exception {

	URL skinURL = jnlptest.class.getClassLoader().getResource("whistler/skinlf-themepack.xml");
	System.out.println("skinURL is " + skinURL);

	Skin skin = SkinLookAndFeel.loadThemePackDefinition(skinURL);
	SkinLookAndFeel.setSkin(skin);

	UIManager.setLookAndFeel(new SkinLookAndFeel());

	JFrame f = new JFrame();
	f.getContentPane().add(new JButton("Hello!"));
	f.setVisible(true);

    }

}
